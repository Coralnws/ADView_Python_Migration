from setuptools import setup

setup(
    name = "ADViewpy",
    version = '0.0.1'
)